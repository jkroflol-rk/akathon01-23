<?php

include('./js/func.php');

$test = uuid();

echo uuid();
?>