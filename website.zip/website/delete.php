<!DOCTYPE html>
<html>
  <head>
    <title>Delete Animation Example</title>
    <link rel="stylesheet" href="style/test.css">
    <!-- <script src="js/djtmeakathon.js"></script> -->

</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                Card 1
                <button class="delete-button">&times;</button>
            </div>
            <div class="card-body">
                This is the content of Card 1.
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                Card 2
                <button class="delete-button">&times;</button>
            </div>
            <div class="card-body">
                This is the content of Card 2.
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                Card 3
                <button class="delete-button">&times;</button>
            </div>
            <div class="card-body">
                This is the content of Card 3.
            </div>


        </div>
        <div class="card">
            <div class="card-header">
                Card 3
                <button class="delete-button">&times;</button>
            </div>
            <div class="card-body">
                This is the content of Card 4.
            </div>


        </div>
        <div class="card">
            <div class="card-header">
                Card 3
                <button class="delete-button">&times;</button>
            </div>
            <div class="card-body">
                This is the content of Card 5.
            </div>


        </div>
        <div class="card">
            <div class="card-header">
                Card 3
                <button class="delete-button">&times;</button>
            </div>
            <div class="card-body">
                This is the content of Card 6.
            </div>


        </div>
        <div class="card">
            <div class="card-header">
                Card 3
                <button class="delete-button">&times;</button>
            </div>
            <div class="card-body">
                This is the content of Card 7.
            </div>


        </div>
</div>

<!-- <script src="script.js"></script> -->
<script src="js/djtmeakathon.js"></script>

  </body>
</html>
